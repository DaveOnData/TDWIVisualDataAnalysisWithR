#=======================================================================================
#
# File:        InstallPackages.R
# Authors:     Dave Langer
# Description: This code was written as part of the 1-day course "Hands-on: Visual Data 
#              Analysis with R" 
#
# NOTE - This file is provided "As-Is" and no warranty regarding its contents is
#        offered nor implied. USE AT YOUR OWN RISK!
#
#=======================================================================================


# Install packages required for the course.
install.packages(c("tidyverse", "nycflights13"),
                 dependencies = TRUE)


library(tidyverse)
library(nycflights13)
